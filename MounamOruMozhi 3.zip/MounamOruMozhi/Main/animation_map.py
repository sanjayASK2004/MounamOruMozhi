animation_dict = {
    "hello": "Assets/animations/hello.gif",
    "thank you": "Assets/animations/thankyou.gif",
    "welcome": "Assets/animations/welcome.gif",
    "yes": "Assets/animations/yes.gif",
    "no": "Assets/animations/no.gif",
    "sorry": "Assets/animations/sorry.gif",
    "please": "Assets/animations/please.gif",
    "good morning": "Assets/animations/goodmorning.gif",
    "good night": "Assets/animations/goodnight.gif",
    "goodbye": "Assets/animations/goodbye.gif"
}

def get_animation(word):
    """
    Retrieve the animation file path based on the recognized word.
    """
    return animation_dict.get(word.lower(), None)
