from gtts import gTTS
import os

class TamilTTS:
    def __init__(self, lang="ta"):
        self.lang = lang

    def text_to_speech(self, text, output_file="Assets/sounds/output.mp3"):
        tts = gTTS(text, lang=self.lang)
        tts.save(output_file)
        os.system(f"start {output_file}")  # Opens audio file for playback
