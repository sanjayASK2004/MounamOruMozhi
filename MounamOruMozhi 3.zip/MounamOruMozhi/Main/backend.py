﻿import sys
from PyQt5.QtWidgets import QApplication, QWidget, QLabel, QPushButton, QVBoxLayout, QHBoxLayout, QStackedWidget, QRadioButton
from PyQt5.QtGui import QFont, QPixmap, QMovie
from PyQt5.QtCore import Qt, QTimer
import speech_recognition as sr
import os

class SignLanguageApp(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()
        self.recognizer = sr.Recognizer()
        self.selected_language = "ta-IN"
        
    def initUI(self):
        self.setWindowTitle("மௌனம் ஒரு மொழி - Sign Language App")
        self.setGeometry(100, 100, 1024, 768)
        
        self.stackedWidget = QStackedWidget(self)
        
        self.page1 = self.createPage1()
        self.page2 = self.createPage2()
        self.page3 = self.createPage3()
        self.page4 = self.createPage4()
        
        self.stackedWidget.addWidget(self.page1)
        self.stackedWidget.addWidget(self.page2)
        self.stackedWidget.addWidget(self.page3)
        self.stackedWidget.addWidget(self.page4)
        
        layout = QVBoxLayout()
        layout.addWidget(self.stackedWidget)
        self.setLayout(layout)
        
    def createPage1(self):
        page = QWidget()
        layout = QVBoxLayout()
        
        title = QLabel("மௌனம் ஒரு மொழி", self)
        title.setFont(QFont("Arial", 36, QFont.Bold))
        title.setAlignment(Qt.AlignCenter)
        
        logo = QLabel(self)
        pixmap = QPixmap("Assets/icons/logo.png")
        logo.setPixmap(pixmap)
        logo.setAlignment(Qt.AlignCenter)
        
        startBtn = QPushButton("▶", self)
        startBtn.setFont(QFont("Arial", 36, QFont.Bold))
        startBtn.clicked.connect(lambda: self.stackedWidget.setCurrentIndex(1))
        
        layout.addWidget(title)
        layout.addWidget(logo)
        layout.addWidget(startBtn)
        layout.setAlignment(Qt.AlignCenter)
        page.setLayout(layout)
        return page
    
    def createPage2(self):
        page = QWidget()
        layout = QVBoxLayout()
        
        title = QLabel("மௌனம் ஒரு மொழி", self)
        title.setFont(QFont("Arial", 36, QFont.Bold))
        title.setAlignment(Qt.AlignCenter)
        
        icon = QLabel("🙏 வணக்கம்", self)
        icon.setFont(QFont("Arial", 32))
        icon.setAlignment(Qt.AlignCenter)
        
        self.tamilBtn = QRadioButton("தமிழ்", self)
        self.englishBtn = QRadioButton("English", self)
        self.tamilBtn.setChecked(True)
        
        self.tamilBtn.toggled.connect(lambda: self.setLanguage("ta-IN"))
        self.englishBtn.toggled.connect(lambda: self.setLanguage("en-IN"))
        
        startBtn = QPushButton("Start", self)
        startBtn.setFont(QFont("Arial", 24))
        startBtn.clicked.connect(lambda: self.stackedWidget.setCurrentIndex(2))
        
        layout.addWidget(title)
        layout.addWidget(icon)
        layout.addWidget(self.tamilBtn)
        layout.addWidget(self.englishBtn)
        layout.addWidget(startBtn)
        layout.setAlignment(Qt.AlignCenter)
        page.setLayout(layout)
        return page
    
    def setLanguage(self, lang):
        self.selected_language = lang
    
    def createPage3(self):
        page = QWidget()
        layout = QVBoxLayout()
        
        title = QLabel("மௌனம் ஒரு மொழி", self)
        title.setFont(QFont("Arial", 36, QFont.Bold))
        title.setAlignment(Qt.AlignCenter)
        
        logo = QLabel("🔊", self)
        logo.setFont(QFont("Arial", 48))
        logo.setAlignment(Qt.AlignCenter)
        
        startBtn = QPushButton("Start Speaking", self)
        startBtn.setFont(QFont("Arial", 24))
        startBtn.clicked.connect(lambda: self.stackedWidget.setCurrentIndex(3))
        
        exitBtn = QPushButton("Exit", self)
        exitBtn.setFont(QFont("Arial", 24))
        exitBtn.clicked.connect(lambda: self.stackedWidget.setCurrentIndex(1))
        
        layout.addWidget(title)
        layout.addWidget(logo)
        layout.addWidget(startBtn)
        layout.addWidget(exitBtn)
        layout.setAlignment(Qt.AlignCenter)
        page.setLayout(layout)
        return page
    
    def createPage4(self):
        page = QWidget()
        layout = QVBoxLayout()
        
        micIcon = QLabel("🎤", self)
        micIcon.setFont(QFont("Arial", 48))
        micIcon.setAlignment(Qt.AlignLeft)
        
        self.speechText = QLabel("", self)
        self.speechText.setFont(QFont("Arial", 32, QFont.Bold))
        self.speechText.setAlignment(Qt.AlignLeft)
        self.speechText.setStyleSheet("color: black;")
        
        self.gifLabel = QLabel(self)
        self.gifLabel.setFixedSize(800, 400)
        self.gifLabel.setAlignment(Qt.AlignCenter)
        
        self.startListening()
        
        stopBtn = QPushButton("Stop", self)
        stopBtn.setFont(QFont("Arial", 24))
        stopBtn.clicked.connect(lambda: self.stackedWidget.setCurrentIndex(2))
        
        layout.addWidget(micIcon)
        layout.addWidget(self.speechText)
        layout.addWidget(self.gifLabel)
        layout.addWidget(stopBtn)
        layout.setAlignment(Qt.AlignCenter)
        page.setLayout(layout)
        return page
    
    def startListening(self):
        try:
            self.microphone = sr.Microphone()
            with self.microphone as source:
                self.recognizer.adjust_for_ambient_noise(source)
            self.listenForSpeech()
        except Exception as e:
            print(f"Microphone error: {e}")
    
    def listenForSpeech(self):
        try:
            with self.microphone as source:
                print("Listening...")
                audio = self.recognizer.listen(source)
                recognized_text = self.recognizer.recognize_google(audio, language=self.selected_language)
                self.speechText.setText(recognized_text)
                self.displayGif(recognized_text)
        except sr.UnknownValueError:
            self.speechText.setText("Speech not recognized")
        except sr.RequestError:
            self.speechText.setText("Error in speech recognition service")
        QTimer.singleShot(1000, self.listenForSpeech)
    
    def displayGif(self, text):
        animation_path = os.path.join("Assets/animations", f"{text}.gif")
        if os.path.exists(animation_path):
            movie = QMovie(animation_path)
            self.gifLabel.setMovie(movie)
            movie.start()
        else:
            self.gifLabel.setText("No animation found")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = SignLanguageApp()
    window.show()
    sys.exit(app.exec_())
