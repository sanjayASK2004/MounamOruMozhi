import json

class TextAnalysis:
    def __init__(self, animation_file="Assets/animation_map.json"):
        self.animation_file = animation_file
        self.load_animation_data()

    def load_animation_data(self):
        try:
            with open(self.animation_file, "r", encoding="utf-8") as file:
                self.animation_data = json.load(file)
        except FileNotFoundError:
            self.animation_data = {}

    def get_animation_for_word(self, word):
        return self.animation_data.get(word, None)
