from PyQt5.QtWidgets import QApplication, QMainWindow, QLabel
from PyQt5.QtGui import QFont
from PyQt5.QtCore import Qt

class UI(QMainWindow):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        self.setWindowTitle("Mounam Oru Mozhi")
        self.setGeometry(100, 100, 800, 600)
        self.setStyleSheet("background-color: black; color: white;")

        self.label = QLabel("Mounam Oru Mozhi", self)
        self.label.setAlignment(Qt.AlignCenter)
        self.label.setFont(QFont("Arial", 24))
        self.label.setGeometry(200, 200, 400, 100)
