import json

class AudioSettings:
    def __init__(self, config_file="Setting/config.json"):
        self.config_file = config_file
        self.load_settings()

    def load_settings(self):
        try:
            with open(self.config_file, "r", encoding="utf-8") as file:
                self.settings = json.load(file)
        except FileNotFoundError:
            self.settings = {"volume": 50, "noise_suppression": True}

    def get_volume(self):
        return self.settings.get("volume", 50)

    def set_volume(self, volume):
        self.settings["volume"] = volume
        self.save_settings()

    def toggle_noise_suppression(self):
        self.settings["noise_suppression"] = not self.settings["noise_suppression"]
        self.save_settings()

    def save_settings(self):
        with open(self.config_file, "w", encoding="utf-8") as file:
            json.dump(self.settings, file, indent=4)
