# Mounam Oru Mozhi - Tamil Sign Language Converter

## Overview
Mounam Oru Mozhi is a Windows application that converts Tamil speech into sign language animations.

## Features
- Tamil speech recognition
- Text display in Tamil fonts
- Animation retrieval (GIF & MP4) from Assets folder
- Custom UI with dark & light themes
- Adjustable animation playback speed
- Sound control & noise suppression

## Folder Structure
